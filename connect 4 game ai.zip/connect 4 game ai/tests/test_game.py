"""
Unit tests for ConnectFour game mechanics and board state evaluation.
"""

import numpy as np
import pytest

from game import (
    ConnectFour,
    ROWS,
    COLS,
    EMPTY,
    PLAYER_PIECE,
    AI_PIECE
)


def test_board_initialization():
    """Verify board starts with correct dimensions and all cells empty."""
    game = ConnectFour()
    assert game.board.shape == (ROWS, COLS)
    assert np.all(game.board == EMPTY)


def test_drop_piece_and_gravity():
    """Verify pieces drop to the lowest available row in a column."""
    game = ConnectFour()
    col = 3

    # Drop first piece
    r1 = game.get_next_open_row(game.board, col)
    assert r1 == 0
    game.drop_piece(game.board, r1, col, PLAYER_PIECE)
    assert game.board[0][col] == PLAYER_PIECE

    # Drop second piece in same column
    r2 = game.get_next_open_row(game.board, col)
    assert r2 == 1
    game.drop_piece(game.board, r2, col, AI_PIECE)
    assert game.board[1][col] == AI_PIECE


def test_full_column_rejection():
    """Verify that a full column cannot accept additional moves."""
    game = ConnectFour()
    col = 0

    # Fill all 6 rows of column 0
    for r in range(ROWS):
        assert game.is_valid_location(game.board, col)
        row = game.get_next_open_row(game.board, col)
        assert row == r
        game.drop_piece(game.board, row, col, PLAYER_PIECE)

    # Column is now full
    assert not game.is_valid_location(game.board, col)
    assert game.get_next_open_row(game.board, col) is None
    assert col not in game.get_valid_locations(game.board)


def test_horizontal_win():
    """Verify horizontal 4-in-a-row is detected correctly."""
    game = ConnectFour()
    row = 0
    for col in range(4):
        game.drop_piece(game.board, row, col, PLAYER_PIECE)

    assert game.check_win(game.board, PLAYER_PIECE)
    assert not game.check_win(game.board, AI_PIECE)

    win_pos = game.get_winning_positions(game.board, PLAYER_PIECE)
    assert len(win_pos) == 4
    assert win_pos == [(0, 0), (0, 1), (0, 2), (0, 3)]


def test_vertical_win():
    """Verify vertical 4-in-a-row is detected correctly."""
    game = ConnectFour()
    col = 5
    for r in range(4):
        game.drop_piece(game.board, r, col, AI_PIECE)

    assert game.check_win(game.board, AI_PIECE)
    assert not game.check_win(game.board, PLAYER_PIECE)

    win_pos = game.get_winning_positions(game.board, AI_PIECE)
    assert len(win_pos) == 4
    assert win_pos == [(0, 5), (1, 5), (2, 5), (3, 5)]


def test_positive_diagonal_win():
    """
    Verify positively sloped diagonal (/) win:
    Positions: (0,0), (1,1), (2,2), (3,3)
    """
    game = ConnectFour()
    # (0, 0)
    game.drop_piece(game.board, 0, 0, PLAYER_PIECE)

    # (1, 1): Needs 1 piece under it
    game.drop_piece(game.board, 0, 1, AI_PIECE)
    game.drop_piece(game.board, 1, 1, PLAYER_PIECE)

    # (2, 2): Needs 2 pieces under it
    game.drop_piece(game.board, 0, 2, AI_PIECE)
    game.drop_piece(game.board, 1, 2, AI_PIECE)
    game.drop_piece(game.board, 2, 2, PLAYER_PIECE)

    # (3, 3): Needs 3 pieces under it
    game.drop_piece(game.board, 0, 3, AI_PIECE)
    game.drop_piece(game.board, 1, 3, AI_PIECE)
    game.drop_piece(game.board, 2, 3, AI_PIECE)
    game.drop_piece(game.board, 3, 3, PLAYER_PIECE)

    assert game.check_win(game.board, PLAYER_PIECE)
    win_pos = game.get_winning_positions(game.board, PLAYER_PIECE)
    assert win_pos == [(0, 0), (1, 1), (2, 2), (3, 3)]


def test_negative_diagonal_win():
    """
    Verify negatively sloped diagonal (\\) win:
    Positions: (3,0), (2,1), (1,2), (0,3)
    """
    game = ConnectFour()
    # (3, 0): Needs 3 pieces under it
    game.drop_piece(game.board, 0, 0, AI_PIECE)
    game.drop_piece(game.board, 1, 0, AI_PIECE)
    game.drop_piece(game.board, 2, 0, AI_PIECE)
    game.drop_piece(game.board, 3, 0, PLAYER_PIECE)

    # (2, 1): Needs 2 pieces under it
    game.drop_piece(game.board, 0, 1, AI_PIECE)
    game.drop_piece(game.board, 1, 1, AI_PIECE)
    game.drop_piece(game.board, 2, 1, PLAYER_PIECE)

    # (1, 2): Needs 1 piece under it
    game.drop_piece(game.board, 0, 2, AI_PIECE)
    game.drop_piece(game.board, 1, 2, PLAYER_PIECE)

    # (0, 3)
    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)

    assert game.check_win(game.board, PLAYER_PIECE)
    win_pos = game.get_winning_positions(game.board, PLAYER_PIECE)
    assert win_pos == [(3, 0), (2, 1), (1, 2), (0, 3)]


def test_draw_condition():
    """Verify that a full board with no 4-in-a-row is detected as a draw."""
    game = ConnectFour()
    # Construct a known draw board pattern with alternating pairs:
    # 1 1 2 2 1 1 2
    # 2 2 1 1 2 2 1
    # 1 1 2 2 1 1 2
    # 2 2 1 1 2 2 1
    # 1 1 2 2 1 1 2
    # 2 2 1 1 2 2 1
    pattern = [
        [1, 1, 2, 2, 1, 1, 2],
        [2, 2, 1, 1, 2, 2, 1],
        [1, 1, 2, 2, 1, 1, 2],
        [2, 2, 1, 1, 2, 2, 1],
        [1, 1, 2, 2, 1, 1, 2],
        [2, 2, 1, 1, 2, 2, 1],
    ]
    game.board = np.array(pattern, dtype=int)

    assert not game.check_win(game.board, PLAYER_PIECE)
    assert not game.check_win(game.board, AI_PIECE)
    assert len(game.get_valid_locations(game.board)) == 0
    assert game.is_draw(game.board)
    assert game.is_terminal_node(game.board)


def test_reset_game():
    """Verify resetting the game clears the board completely."""
    game = ConnectFour()
    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)
    assert game.board[0][3] == PLAYER_PIECE

    game.reset()
    assert np.all(game.board == EMPTY)
