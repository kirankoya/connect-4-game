"""
Integration and simulation tests for complete Connect Four game loops.
Verifies turn alternations, AI automated responses, and terminal state triggers.
"""

import numpy as np
import pytest

from game import (
    ConnectFour,
    ROWS,
    COLS,
    PLAYER_PIECE,
    AI_PIECE
)
from ai import AIPlayer


def test_full_game_simulation():
    """
    Simulates a sequence of alternating turns between Human and AI.
    Verifies that moves are legally made, columns don't overflow,
    and game terminates appropriately if win occurs.
    """
    game = ConnectFour()
    ai = AIPlayer(depth=3)
    turn = PLAYER_PIECE
    moves_count = 0

    # Simulate up to 10 moves
    for _ in range(10):
        if ConnectFour.is_terminal_node(game.board):
            break

        valid_cols = ConnectFour.get_valid_locations(game.board)
        assert len(valid_cols) > 0

        if turn == PLAYER_PIECE:
            # Human drops in first valid column
            col = valid_cols[0]
            row = ConnectFour.get_next_open_row(game.board, col)
            assert row is not None
            ConnectFour.drop_piece(game.board, row, col, PLAYER_PIECE)
            turn = AI_PIECE
        else:
            # AI computes and makes move
            col, _ = ai.get_best_move(game.board)
            assert col in valid_cols
            row = ConnectFour.get_next_open_row(game.board, col)
            assert row is not None
            ConnectFour.drop_piece(game.board, row, col, AI_PIECE)
            assert ai.nodes_evaluated > 0
            turn = PLAYER_PIECE

        moves_count += 1

    assert moves_count == 10 or ConnectFour.is_terminal_node(game.board)
    assert np.count_nonzero(game.board) == moves_count


def test_ai_handles_various_depths():
    """Verifies AI functions across various depth limits (1, 2, 3, 4, 5)."""
    game = ConnectFour()
    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)

    for depth in [1, 2, 3, 4, 5]:
        ai = AIPlayer(depth=depth)
        col, score = ai.get_best_move(game.board)
        assert col in range(COLS)
        assert ai.nodes_evaluated > 0
        if depth >= 3:
            assert ai.pruning_cutoffs > 0


def test_restart_flow():
    """Verifies that state reset accurately clears game and AI statistics."""
    game = ConnectFour()
    ai = AIPlayer(depth=3)

    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)
    ai.get_best_move(game.board)

    assert np.count_nonzero(game.board) > 0
    assert ai.nodes_evaluated > 0

    # Reset
    game.reset()
    ai.reset_stats()

    assert np.all(game.board == 0)
    assert ai.nodes_evaluated == 0
    assert ai.pruning_cutoffs == 0
    assert ai.last_move is None
