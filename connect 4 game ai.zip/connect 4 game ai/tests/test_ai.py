"""
Unit tests for AI Minimax algorithm, Alpha-Beta Pruning, and Heuristic Evaluation.
"""

import numpy as np
import pytest

from game import (
    ConnectFour,
    ROWS,
    COLS,
    EMPTY,
    PLAYER_PIECE,
    AI_PIECE
)
from ai import AIPlayer, MOVE_ORDERING


def test_ai_takes_immediate_horizontal_win():
    """Verify that the AI seizes an immediate horizontal winning opportunity."""
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Place 3 AI pieces horizontally at row 0, cols 0, 1, 2
    game.drop_piece(game.board, 0, 0, AI_PIECE)
    game.drop_piece(game.board, 0, 1, AI_PIECE)
    game.drop_piece(game.board, 0, 2, AI_PIECE)

    # Column 3 is the winning drop!
    best_col, score = ai.get_best_move(game.board)
    assert best_col == 3
    assert score > 1000000  # High terminal winning score


def test_ai_takes_immediate_vertical_win():
    """Verify that the AI seizes an immediate vertical winning opportunity."""
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Place 3 AI pieces vertically at col 4, rows 0, 1, 2
    game.drop_piece(game.board, 0, 4, AI_PIECE)
    game.drop_piece(game.board, 1, 4, AI_PIECE)
    game.drop_piece(game.board, 2, 4, AI_PIECE)

    # Column 4 is the winning drop!
    best_col, score = ai.get_best_move(game.board)
    assert best_col == 4
    assert score > 1000000


def test_ai_takes_diagonal_win():
    """Verify that the AI recognizes and seizes a diagonal winning move."""
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Setup 3 AI pieces along positive diagonal: (0,0), (1,1), (2,2)
    # With supporting pieces underneath
    game.drop_piece(game.board, 0, 0, AI_PIECE)

    game.drop_piece(game.board, 0, 1, PLAYER_PIECE)
    game.drop_piece(game.board, 1, 1, AI_PIECE)

    game.drop_piece(game.board, 0, 2, PLAYER_PIECE)
    game.drop_piece(game.board, 1, 2, PLAYER_PIECE)
    game.drop_piece(game.board, 2, 2, AI_PIECE)

    # In col 3: we place 3 supporting pieces so the next drop lands at (3, 3)
    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)
    game.drop_piece(game.board, 1, 3, PLAYER_PIECE)
    game.drop_piece(game.board, 2, 3, PLAYER_PIECE)

    best_col, score = ai.get_best_move(game.board)
    assert best_col == 3
    assert score > 1000000


def test_ai_blocks_immediate_horizontal_human_win():
    """Verify that the AI blocks a human player's immediate 4-in-a-row threat."""
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Human has 3 discs at row 0, cols 1, 2, 3
    game.drop_piece(game.board, 0, 1, PLAYER_PIECE)
    game.drop_piece(game.board, 0, 2, PLAYER_PIECE)
    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)

    # Winning spots for human are col 0 and col 4.
    # AI must choose either col 0 or col 4 to block!
    best_col, _ = ai.get_best_move(game.board)
    assert best_col in [0, 4]


def test_ai_blocks_immediate_vertical_human_win():
    """Verify that the AI blocks an immediate vertical human win."""
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Human has 3 discs stacked vertically at col 2, rows 0, 1, 2
    game.drop_piece(game.board, 0, 2, PLAYER_PIECE)
    game.drop_piece(game.board, 1, 2, PLAYER_PIECE)
    game.drop_piece(game.board, 2, 2, PLAYER_PIECE)

    # AI must drop in col 2 to block row 3!
    best_col, _ = ai.get_best_move(game.board)
    assert best_col == 2


def test_ai_blocks_diagonal_human_win():
    """Verify that the AI blocks an immediate human diagonal winning move."""
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Human diagonal at (0,0), (1,1), (2,2), with col 3 ready at row 3
    game.drop_piece(game.board, 0, 0, PLAYER_PIECE)

    game.drop_piece(game.board, 0, 1, AI_PIECE)
    game.drop_piece(game.board, 1, 1, PLAYER_PIECE)

    game.drop_piece(game.board, 0, 2, AI_PIECE)
    game.drop_piece(game.board, 1, 2, AI_PIECE)
    game.drop_piece(game.board, 2, 2, PLAYER_PIECE)

    # Col 3 has 3 pieces underneath, next drop is (3, 3)
    game.drop_piece(game.board, 0, 3, AI_PIECE)
    game.drop_piece(game.board, 1, 3, AI_PIECE)
    game.drop_piece(game.board, 2, 3, AI_PIECE)

    # Col 3 must be blocked
    best_col, _ = ai.get_best_move(game.board)
    assert best_col == 3


def test_alpha_beta_pruning_execution():
    """
    Verify that Alpha-Beta pruning actively cuts branches.
    Pruning cutoffs must be strictly greater than 0 on depth >= 3 search.
    """
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    # Play a couple of moves to create a branching tree
    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)
    game.drop_piece(game.board, 0, 2, AI_PIECE)

    best_col, _ = ai.get_best_move(game.board)
    assert best_col in range(7)
    assert ai.nodes_evaluated > 0
    assert ai.pruning_cutoffs > 0  # Crucial: proves Alpha-Beta is genuinely cutting branches!
    assert ai.execution_time_ms >= 0.0


def test_center_column_preference_on_empty_board():
    """
    In Connect Four, column 3 (center) is mathematically the strongest opening.
    Verify the AI selects center column 3 on an empty board.
    """
    game = ConnectFour()
    ai = AIPlayer(depth=4)

    best_col, _ = ai.get_best_move(game.board)
    assert best_col == 3


def test_move_ordering_structure():
    """Verify that move ordering lists center columns first."""
    ai = AIPlayer()
    ordered = ai.order_moves([0, 1, 2, 3, 4, 5, 6])
    assert ordered[0] == 3
    assert set(ordered[:3]) == {2, 3, 4}


def test_stats_reset():
    """Verify search metrics are properly reset before each move evaluation."""
    game = ConnectFour()
    ai = AIPlayer(depth=3)

    game.drop_piece(game.board, 0, 3, PLAYER_PIECE)
    ai.get_best_move(game.board)
    assert ai.nodes_evaluated > 0

    ai.reset_stats()
    assert ai.nodes_evaluated == 0
    assert ai.pruning_cutoffs == 0
    assert ai.last_move is None
