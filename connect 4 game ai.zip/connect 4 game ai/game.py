"""
Connect Four: Game Logic and Board Representation Module.

This module encapsulates all board operations, move validation, gravity logic,
and win/draw evaluation for the 6x7 Connect Four game.

Authors: Student-Friendly FAI Case Study Implementation
"""

from typing import List, Tuple, Optional
import numpy as np

# Board Dimensions (Standard Connect Four)
ROWS: int = 6
COLS: int = 7

# Piece Identifiers
EMPTY: int = 0
PLAYER_PIECE: int = 1  # Human (Red)
AI_PIECE: int = 2      # AI Opponent (Yellow)

# Game Parameters
WINDOW_LENGTH: int = 4


class ConnectFour:
    """
    Represents the Connect Four game state and rules engine.
    
    Attributes:
        rows (int): Number of rows (default: 6).
        cols (int): Number of columns (default: 7).
        board (np.ndarray): 2D integer array where:
            - 0 represents an empty cell.
            - 1 represents Human player's disc (Red).
            - 2 represents AI player's disc (Yellow).
            Row 0 is the bottom row; Row (rows-1) is the top row.
    """

    def __init__(self, rows: int = ROWS, cols: int = COLS) -> None:
        self.rows: int = rows
        self.cols: int = cols
        self.board: np.ndarray = self.create_board()

    def create_board(self) -> np.ndarray:
        """Create and return an empty 6x7 board filled with zeros."""
        return np.zeros((self.rows, self.cols), dtype=int)

    def reset(self) -> None:
        """Reset the board to an empty state."""
        self.board = self.create_board()

    @staticmethod
    def is_valid_location(board: np.ndarray, col: int) -> bool:
        """
        Check if a given column has space for a new disc.
        
        A column is valid if the top cell (row = ROWS - 1) is EMPTY.
        """
        if 0 <= col < COLS:
            return board[ROWS - 1][col] == EMPTY
        return False

    @staticmethod
    def get_next_open_row(board: np.ndarray, col: int) -> Optional[int]:
        """
        Find the lowest available row index in the specified column (simulating gravity).
        
        Returns:
            The row index (0 to rows-1) if available, or None if the column is full.
        """
        for r in range(ROWS):
            if board[r][col] == EMPTY:
                return r
        return None

    @staticmethod
    def drop_piece(board: np.ndarray, row: int, col: int, piece: int) -> None:
        """Place a disc of the given piece type into the specified row and column."""
        board[row][col] = piece

    @staticmethod
    def get_valid_locations(board: np.ndarray) -> List[int]:
        """Return a list of column indices that are not yet full."""
        return [col for col in range(COLS) if ConnectFour.is_valid_location(board, col)]

    @staticmethod
    def check_win(board: np.ndarray, piece: int) -> bool:
        """
        Check if the specified player has 4 consecutive discs in any direction:
        - Horizontal
        - Vertical
        - Positively sloped diagonal (/)
        - Negatively sloped diagonal (\\)
        """
        # Check horizontal locations
        for c in range(COLS - 3):
            for r in range(ROWS):
                if (board[r][c] == piece and
                        board[r][c + 1] == piece and
                        board[r][c + 2] == piece and
                        board[r][c + 3] == piece):
                    return True

        # Check vertical locations
        for c in range(COLS):
            for r in range(ROWS - 3):
                if (board[r][c] == piece and
                        board[r + 1][c] == piece and
                        board[r + 2][c] == piece and
                        board[r + 3][c] == piece):
                    return True

        # Check positively sloped diagonals (/)
        for c in range(COLS - 3):
            for r in range(ROWS - 3):
                if (board[r][c] == piece and
                        board[r + 1][c + 1] == piece and
                        board[r + 2][c + 2] == piece and
                        board[r + 3][c + 3] == piece):
                    return True

        # Check negatively sloped diagonals (\)
        for c in range(COLS - 3):
            for r in range(3, ROWS):
                if (board[r][c] == piece and
                        board[r - 1][c + 1] == piece and
                        board[r - 2][c + 2] == piece and
                        board[r - 3][c + 3] == piece):
                    return True

        return False

    @staticmethod
    def get_winning_positions(board: np.ndarray, piece: int) -> List[Tuple[int, int]]:
        """
        Identify the exact (row, col) coordinates of the 4 winning pieces.
        
        Returns:
            A list of 4 (row, col) tuples if a win exists, otherwise an empty list.
        """
        # Horizontal
        for c in range(COLS - 3):
            for r in range(ROWS):
                if all(board[r][c + i] == piece for i in range(4)):
                    return [(r, c + i) for i in range(4)]

        # Vertical
        for c in range(COLS):
            for r in range(ROWS - 3):
                if all(board[r + i][c] == piece for i in range(4)):
                    return [(r + i, c) for i in range(4)]

        # Positively sloped diagonal (/)
        for c in range(COLS - 3):
            for r in range(ROWS - 3):
                if all(board[r + i][c + i] == piece for i in range(4)):
                    return [(r + i, c + i) for i in range(4)]

        # Negatively sloped diagonal (\)
        for c in range(COLS - 3):
            for r in range(3, ROWS):
                if all(board[r - i][c + i] == piece for i in range(4)):
                    return [(r - i, c + i) for i in range(4)]

        return []

    @staticmethod
    def is_draw(board: np.ndarray) -> bool:
        """
        Check if the game has ended in a draw.
        
        A draw occurs when the board has no empty spots left and neither player has won.
        """
        if len(ConnectFour.get_valid_locations(board)) == 0:
            return not (ConnectFour.check_win(board, PLAYER_PIECE) or
                        ConnectFour.check_win(board, AI_PIECE))
        return False

    @staticmethod
    def is_terminal_node(board: np.ndarray) -> bool:
        """
        Check if the game is in a terminal state (win for either player or draw).
        """
        return (ConnectFour.check_win(board, PLAYER_PIECE) or
                ConnectFour.check_win(board, AI_PIECE) or
                len(ConnectFour.get_valid_locations(board)) == 0)

    @staticmethod
    def copy_board(board: np.ndarray) -> np.ndarray:
        """Create a deep copy of the board for simulation."""
        return np.copy(board)

    @staticmethod
    def print_board(board: np.ndarray) -> None:
        """
        Print the board to the console with row 0 at the bottom.
        
        Helpful for debugging and terminal-based inspection.
        """
        print(np.flip(board, 0))
