"""
Connect Four AI - Web Demo Server (Flask).

Provides a local web interface on http://localhost:5000 demonstrating
Minimax with Alpha-Beta Pruning, real-time search metrics, and interactive play.

Authors: Student-Friendly FAI Case Study Implementation
"""

import os
from typing import Dict, Any, List, Optional
from flask import Flask, render_template_string, jsonify, request
import numpy as np

from game import (
    ConnectFour,
    ROWS,
    COLS,
    EMPTY,
    PLAYER_PIECE,
    AI_PIECE
)
from ai import AIPlayer

app = Flask(__name__)

# Server-side Game State
game_instance = ConnectFour()
ai_player = AIPlayer(depth=5)
current_turn = PLAYER_PIECE
game_over = False
winner: Optional[int] = None
winning_coords: List[List[int]] = []
last_ai_stats: Dict[str, Any] = {
    "nodes_evaluated": 0,
    "pruning_cutoffs": 0,
    "execution_time_ms": 0.0,
    "selected_column": None,
    "score": None,
    "depth": 5
}


def get_game_state_dict() -> Dict[str, Any]:
    """Serializes the current game state to JSON-friendly dictionary."""
    return {
        "board": game_instance.board.tolist(),
        "turn": current_turn,
        "game_over": game_over,
        "winner": winner,
        "winning_coords": winning_coords,
        "rows": ROWS,
        "cols": COLS,
        "ai_stats": last_ai_stats
    }


# ---------------------------------------------------------
# HTML / CSS / JS TEMPLATE (Modern Responsive UI)
# ---------------------------------------------------------
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Connect Four AI — Minimax with Alpha-Beta Pruning Demo</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-color: #0b1120;
      --card-bg: #1e293b;
      --card-border: #334155;
      --board-color: #1e3a8a;
      --board-rim: #172554;
      --player-color: #ef4444;
      --player-shadow: #991b1b;
      --ai-color: #facc15;
      --ai-shadow: #a16207;
      --win-highlight: #38bdf8;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --accent: #38bdf8;
      --success: #22c55e;
      --slot-size: 72px;
      --slot-gap: 8px;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background: radial-gradient(circle at 50% 10%, #1e293b 0%, #0b1120 100%);
      color: var(--text-main);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px 16px;
    }

    header {
      text-align: center;
      margin-bottom: 24px;
    }

    header h1 {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.5px;
      background: linear-gradient(135deg, #f8fafc 0%, #38bdf8 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 6px;
    }

    header p {
      color: var(--text-muted);
      font-size: 14px;
    }

    .badge-fai {
      display: inline-block;
      padding: 3px 10px;
      background: rgba(56, 189, 248, 0.15);
      border: 1px solid rgba(56, 189, 248, 0.4);
      color: var(--accent);
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 600;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .container {
      display: grid;
      grid-template-columns: auto 380px;
      gap: 32px;
      max-width: 1180px;
      width: 100%;
      align-items: start;
    }

    @media (max-width: 960px) {
      .container {
        grid-template-columns: 1fr;
        justify-items: center;
      }
    }

    /* Game Board Styling */
    .game-area {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .hover-guide {
      display: grid;
      grid-template-columns: repeat(7, var(--slot-size));
      gap: var(--slot-gap);
      height: var(--slot-size);
      margin-bottom: 6px;
      width: calc(7 * var(--slot-size) + 6 * var(--slot-gap) + 24px);
      padding: 0 12px;
    }

    .hover-slot {
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }

    .preview-disc {
      width: calc(var(--slot-size) - 10px);
      height: calc(var(--slot-size) - 10px);
      border-radius: 50%;
      background: radial-gradient(circle at 35% 35%, #fca5a5, var(--player-color));
      box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
      opacity: 0;
      transform: translateY(-8px);
      transition: opacity 0.15s ease, transform 0.15s ease;
    }

    .hover-slot:hover .preview-disc {
      opacity: 0.85;
      transform: translateY(0);
    }

    .board-container {
      background: var(--board-color);
      border: 4px solid var(--board-rim);
      border-radius: 20px;
      padding: 12px;
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7), inset 0 2px 4px rgba(255, 255, 255, 0.1);
      display: grid;
      grid-template-columns: repeat(7, var(--slot-size));
      gap: var(--slot-gap);
      position: relative;
    }

    .slot {
      width: var(--slot-size);
      height: var(--slot-size);
      background-color: #0b1120;
      border-radius: 50%;
      box-shadow: inset 0 6px 10px rgba(0, 0, 0, 0.8), 0 1px 2px rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      cursor: pointer;
    }

    .disc {
      width: calc(var(--slot-size) - 8px);
      height: calc(var(--slot-size) - 8px);
      border-radius: 50%;
      position: absolute;
      transform: translateY(0);
      will-change: transform;
    }

    .disc.player {
      background: radial-gradient(circle at 35% 35%, #fca5a5, var(--player-color) 60%, var(--player-shadow));
      box-shadow: 0 4px 10px rgba(239, 68, 68, 0.4);
    }

    .disc.ai {
      background: radial-gradient(circle at 35% 35%, #fef08a, var(--ai-color) 60%, var(--ai-shadow));
      box-shadow: 0 4px 10px rgba(250, 204, 21, 0.4);
    }

    .disc.drop-anim {
      animation: dropPhysics 0.32s cubic-bezier(0.25, 1, 0.5, 1) forwards;
    }

    @keyframes dropPhysics {
      0% {
        transform: translateY(-400px);
        opacity: 0.5;
      }
      80% {
        transform: translateY(4px);
        opacity: 1;
      }
      100% {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .disc.winner {
      box-shadow: 0 0 0 4px var(--win-highlight), 0 0 20px var(--win-highlight);
      animation: pulseWin 1.2s infinite alternate ease-in-out;
    }

    @keyframes pulseWin {
      from { transform: scale(0.96); filter: brightness(1.1); }
      to { transform: scale(1.05); filter: brightness(1.3); }
    }

    /* Sidebar Panel */
    .sidebar {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 14px;
      padding: 18px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    }

    .card-title {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      color: var(--text-muted);
      margin-bottom: 8px;
    }

    /* Status Card */
    .status-text {
      font-size: 20px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .status-indicator {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: var(--player-color);
      box-shadow: 0 0 8px currentColor;
    }

    .status-indicator.ai { background: var(--ai-color); }
    .status-indicator.win { background: var(--win-highlight); }

    /* Metrics Grid */
    .metrics-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-top: 10px;
    }

    .metric-box {
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(51, 65, 85, 0.7);
      border-radius: 10px;
      padding: 10px 12px;
    }

    .metric-label {
      font-size: 11px;
      color: var(--text-muted);
      margin-bottom: 4px;
    }

    .metric-value {
      font-family: 'JetBrains Mono', monospace;
      font-size: 18px;
      font-weight: 700;
      color: var(--text-main);
    }

    .metric-value.pruned { color: var(--success); }
    .metric-value.highlight { color: var(--accent); }

    /* Controls */
    .depth-selector {
      display: flex;
      gap: 8px;
      margin-top: 8px;
    }

    .depth-btn {
      flex: 1;
      padding: 8px 0;
      border: 1px solid var(--card-border);
      background: #0f172a;
      color: var(--text-muted);
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
    }

    .depth-btn:hover {
      background: #1e293b;
      color: var(--text-main);
    }

    .depth-btn.active {
      background: rgba(56, 189, 248, 0.15);
      border-color: var(--accent);
      color: var(--accent);
    }

    .btn {
      width: 100%;
      padding: 12px;
      border-radius: 10px;
      font-weight: 700;
      font-size: 14px;
      border: none;
      cursor: pointer;
      transition: filter 0.15s ease, transform 0.05s;
      margin-top: 8px;
    }

    .btn:active { transform: translateY(1px); }

    .btn-restart {
      background: #e11d48;
      color: white;
    }
    .btn-restart:hover { filter: brightness(1.1); }

    .btn-ai-first {
      background: #2563eb;
      color: white;
    }
    .btn-ai-first:hover { filter: brightness(1.1); }

    .theory-box {
      font-size: 12px;
      color: var(--text-muted);
      line-height: 1.5;
      background: rgba(15, 23, 42, 0.4);
      padding: 10px;
      border-radius: 8px;
      border-left: 3px solid var(--accent);
      margin-top: 6px;
    }

    .thinking-spinner {
      display: inline-block;
      width: 14px;
      height: 14px;
      border: 2px solid rgba(250, 204, 21, 0.3);
      border-radius: 50%;
      border-top-color: var(--ai-color);
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  <header>
    <div class="badge-fai">Fundamentals of Artificial Intelligence • Case Study</div>
    <h1>Connect Four AI: Minimax & Alpha-Beta Pruning</h1>
    <p>Adversarial Game Tree Search with Heuristic Evaluation & Center Move Ordering</p>
  </header>

  <div class="container">
    <!-- Board Game Area -->
    <div class="game-area">
      <!-- Hover column preview indicator -->
      <div class="hover-guide" id="hoverGuide">
        <!-- Generated by JS -->
      </div>

      <!-- 6x7 Physical Board -->
      <div class="board-container" id="boardContainer">
        <!-- 42 slots generated by JS -->
      </div>
    </div>

    <!-- Sidebar HUD -->
    <div class="sidebar">
      <!-- Current Status -->
      <div class="card">
        <div class="card-title">Match Status</div>
        <div class="status-text" id="statusText">
          <span class="status-indicator" id="statusIndicator"></span>
          <span id="statusMessage">Your Turn (Red)</span>
        </div>
      </div>

      <!-- Live Search Metrics (Requirement 7) -->
      <div class="card">
        <div class="card-title">AI Search Demonstration HUD</div>
        <div class="metrics-grid">
          <div class="metric-box">
            <div class="metric-label">Nodes Evaluated</div>
            <div class="metric-value highlight" id="statNodes">0</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">Pruned (α ≥ β)</div>
            <div class="metric-value pruned" id="statPruned">0</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">Compute Latency</div>
            <div class="metric-value" id="statTime">0 ms</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">AI Column Move</div>
            <div class="metric-value highlight" id="statCol">—</div>
          </div>
          <div class="metric-box" style="grid-column: span 2;">
            <div class="metric-label">Evaluated Board Score</div>
            <div class="metric-value" id="statScore">0.0</div>
          </div>
        </div>
      </div>

      <!-- Difficulty / Depth Selector -->
      <div class="card">
        <div class="card-title">Search Depth Horizon</div>
        <div class="depth-selector">
          <button class="depth-btn" onclick="setDepth(2)" id="btnDepth2">D: 2 (Easy)</button>
          <button class="depth-btn" onclick="setDepth(4)" id="btnDepth4">D: 4 (Med)</button>
          <button class="depth-btn active" onclick="setDepth(5)" id="btnDepth5">D: 5 (Hard)</button>
          <button class="depth-btn" onclick="setDepth(6)" id="btnDepth6">D: 6 (Expert)</button>
        </div>
      </div>

      <!-- Controls -->
      <div class="card">
        <button class="btn btn-restart" onclick="resetGame()">Restart Game</button>
        <button class="btn btn-ai-first" onclick="triggerAIMove()" id="btnAIMove">Let AI Make Move</button>
      </div>

      <!-- Educational Viva Note -->
      <div class="card">
        <div class="card-title">FAI Viva Quick Reference</div>
        <div class="theory-box">
          <strong>Cutoff Principle:</strong> When maximizer finds a value ≥ β, or minimizer finds a value ≤ α, the subtree is skipped. The optimal minimax outcome remains unchanged while saving up to 80% of node computations.
        </div>
      </div>
    </div>
  </div>

  <script>
    const ROWS = 6;
    const COLS = 7;
    let currentDepth = 5;
    let isProcessing = false;
    let currentBoard = [];
    let isGameOver = false;

    // Build the grid DOM
    function initBoardDOM() {
      const hoverGuide = document.getElementById('hoverGuide');
      const boardContainer = document.getElementById('boardContainer');
      hoverGuide.innerHTML = '';
      boardContainer.innerHTML = '';

      for (let c = 0; c < COLS; c++) {
        const hSlot = document.createElement('div');
        hSlot.className = 'hover-slot';
        hSlot.onclick = () => onColumnClick(c);
        const pDisc = document.createElement('div');
        pDisc.className = 'preview-disc';
        hSlot.appendChild(pDisc);
        hoverGuide.appendChild(hSlot);
      }

      // Display rows from top (Row 5) down to bottom (Row 0)
      for (let r = ROWS - 1; r >= 0; r--) {
        for (let c = 0; c < COLS; c++) {
          const slot = document.createElement('div');
          slot.className = 'slot';
          slot.id = `slot-${r}-${c}`;
          slot.onclick = () => onColumnClick(c);
          boardContainer.appendChild(slot);
        }
      }
    }

    async function fetchState() {
      const res = await fetch('/api/state');
      const data = await res.json();
      renderState(data);
    }

    function renderState(data) {
      currentBoard = data.board;
      isGameOver = data.game_over;
      const winner = data.winner;
      const winningCoords = data.winning_coords || [];

      // Update slots
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          const slot = document.getElementById(`slot-${r}-${c}`);
          slot.innerHTML = '';
          const piece = currentBoard[r][c];
          if (piece !== 0) {
            const disc = document.createElement('div');
            disc.className = `disc ${piece === 1 ? 'player' : 'ai'}`;
            // Highlight winning discs
            const isWinPiece = winningCoords.some(([wr, wc]) => wr === r && wc === c);
            if (isWinPiece) {
              disc.classList.add('winner');
            }
            slot.appendChild(disc);
          }
        }
      }

      // Update status
      const statusMsg = document.getElementById('statusMessage');
      const indicator = document.getElementById('statusIndicator');

      if (isGameOver) {
        if (winner === 1) {
          statusMsg.textContent = 'You Won! (Red Discs)';
          indicator.className = 'status-indicator';
        } else if (winner === 2) {
          statusMsg.textContent = 'AI Won! (Yellow Discs)';
          indicator.className = 'status-indicator ai';
        } else {
          statusMsg.textContent = 'Game Drawn!';
          indicator.className = 'status-indicator win';
        }
      } else {
        if (data.turn === 1) {
          statusMsg.textContent = 'Your Turn (Red)';
          indicator.className = 'status-indicator';
        } else {
          statusMsg.innerHTML = 'AI Thinking... <span class="thinking-spinner"></span>';
          indicator.className = 'status-indicator ai';
        }
      }

      // Update Metrics HUD
      if (data.ai_stats) {
        document.getElementById('statNodes').textContent = (data.ai_stats.nodes_evaluated || 0).toLocaleString();
        document.getElementById('statPruned').textContent = (data.ai_stats.pruning_cutoffs || 0).toLocaleString();
        document.getElementById('statTime').textContent = `${data.ai_stats.execution_time_ms || 0} ms`;
        document.getElementById('statCol').textContent = data.ai_stats.selected_column !== null ? `Col ${data.ai_stats.selected_column}` : '—';
        document.getElementById('statScore').textContent = data.ai_stats.score !== null ? Math.round(data.ai_stats.score) : '0';
      }
    }

    async function onColumnClick(col) {
      if (isProcessing || isGameOver) return;
      isProcessing = true;

      // Optimistic AI thinking indicator
      document.getElementById('statusMessage').innerHTML = 'AI Computing... <span class="thinking-spinner"></span>';
      document.getElementById('statusIndicator').className = 'status-indicator ai';

      try {
        const res = await fetch('/api/drop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ col: col, depth: currentDepth })
        });
        const data = await res.json();
        renderState(data);
      } catch (err) {
        console.error(err);
      } finally {
        isProcessing = false;
      }
    }

    async function triggerAIMove() {
      if (isProcessing || isGameOver) return;
      isProcessing = true;
      document.getElementById('statusMessage').innerHTML = 'AI Computing... <span class="thinking-spinner"></span>';

      try {
        const res = await fetch('/api/ai_move', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ depth: currentDepth })
        });
        const data = await res.json();
        renderState(data);
      } catch (err) {
        console.error(err);
      } finally {
        isProcessing = false;
      }
    }

    async function resetGame() {
      const res = await fetch('/api/reset', { method: 'POST' });
      const data = await res.json();
      renderState(data);
    }

    function setDepth(d) {
      currentDepth = d;
      [2, 4, 5, 6].forEach(val => {
        const btn = document.getElementById(`btnDepth${val}`);
        if (val === d) btn.classList.add('active');
        else btn.classList.remove('active');
      });
    }

    // Startup
    initBoardDOM();
    fetchState();
  </script>
</body>
</html>
"""


# ---------------------------------------------------------
# REST API ENDPOINTS
# ---------------------------------------------------------
@app.route("/")
def index():
    """Serves the primary Connect Four web interface."""
    return render_template_string(HTML_TEMPLATE)


@app.route("/api/state", methods=["GET"])
def get_state():
    """Returns the current state of the board and metrics."""
    return jsonify(get_game_state_dict())


@app.route("/api/reset", methods=["POST"])
def reset():
    """Resets the board, AI metrics, and turns."""
    global current_turn, game_over, winner, winning_coords, last_ai_stats
    game_instance.reset()
    ai_player.reset_stats()
    current_turn = PLAYER_PIECE
    game_over = False
    winner = None
    winning_coords = []
    last_ai_stats = {
        "nodes_evaluated": 0,
        "pruning_cutoffs": 0,
        "execution_time_ms": 0.0,
        "selected_column": None,
        "score": None,
        "depth": ai_player.depth
    }
    return jsonify(get_game_state_dict())


@app.route("/api/drop", methods=["POST"])
def drop():
    """
    Executes a Human move followed by an automated AI response.
    """
    global current_turn, game_over, winner, winning_coords, last_ai_stats

    if game_over:
        return jsonify(get_game_state_dict())

    data = request.get_json() or {}
    col = data.get("col")
    depth = data.get("depth", 5)

    if col is None or not ConnectFour.is_valid_location(game_instance.board, col):
        return jsonify({"error": "Invalid column move", **get_game_state_dict()}), 400

    # 1. Human Move (Red)
    row = ConnectFour.get_next_open_row(game_instance.board, col)
    ConnectFour.drop_piece(game_instance.board, row, col, PLAYER_PIECE)

    # Check Human Win or Draw
    if ConnectFour.check_win(game_instance.board, PLAYER_PIECE):
        game_over = True
        winner = PLAYER_PIECE
        winning_coords = [list(pos) for pos in ConnectFour.get_winning_positions(game_instance.board, PLAYER_PIECE)]
        return jsonify(get_game_state_dict())

    if ConnectFour.is_draw(game_instance.board):
        game_over = True
        winner = 0
        return jsonify(get_game_state_dict())

    # 2. AI Turn (Yellow)
    current_turn = AI_PIECE
    ai_col, ai_score = ai_player.get_best_move(game_instance.board, depth=depth)

    last_ai_stats = {
        "nodes_evaluated": ai_player.nodes_evaluated,
        "pruning_cutoffs": ai_player.pruning_cutoffs,
        "execution_time_ms": ai_player.execution_time_ms,
        "selected_column": ai_col,
        "score": ai_score,
        "depth": depth
    }

    if ConnectFour.is_valid_location(game_instance.board, ai_col):
        ai_row = ConnectFour.get_next_open_row(game_instance.board, ai_col)
        ConnectFour.drop_piece(game_instance.board, ai_row, ai_col, AI_PIECE)

        if ConnectFour.check_win(game_instance.board, AI_PIECE):
            game_over = True
            winner = AI_PIECE
            winning_coords = [list(pos) for pos in ConnectFour.get_winning_positions(game_instance.board, AI_PIECE)]
        elif ConnectFour.is_draw(game_instance.board):
            game_over = True
            winner = 0
        else:
            current_turn = PLAYER_PIECE

    return jsonify(get_game_state_dict())


@app.route("/api/ai_move", methods=["POST"])
def ai_move():
    """Forces the AI to make a move (e.g. AI first or manual step)."""
    global current_turn, game_over, winner, winning_coords, last_ai_stats

    if game_over:
        return jsonify(get_game_state_dict())

    data = request.get_json() or {}
    depth = data.get("depth", 5)

    ai_col, ai_score = ai_player.get_best_move(game_instance.board, depth=depth)

    last_ai_stats = {
        "nodes_evaluated": ai_player.nodes_evaluated,
        "pruning_cutoffs": ai_player.pruning_cutoffs,
        "execution_time_ms": ai_player.execution_time_ms,
        "selected_column": ai_col,
        "score": ai_score,
        "depth": depth
    }

    if ConnectFour.is_valid_location(game_instance.board, ai_col):
        ai_row = ConnectFour.get_next_open_row(game_instance.board, ai_col)
        ConnectFour.drop_piece(game_instance.board, ai_row, ai_col, AI_PIECE)

        if ConnectFour.check_win(game_instance.board, AI_PIECE):
            game_over = True
            winner = AI_PIECE
            winning_coords = [list(pos) for pos in ConnectFour.get_winning_positions(game_instance.board, AI_PIECE)]
        elif ConnectFour.is_draw(game_instance.board):
            game_over = True
            winner = 0
        else:
            current_turn = PLAYER_PIECE

    return jsonify(get_game_state_dict())


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting Connect Four AI Web Server on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
