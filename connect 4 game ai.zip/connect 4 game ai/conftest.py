"""
Pytest configuration for Connect Four AI project.
Ensures root directory is in sys.path for test discovery.
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
