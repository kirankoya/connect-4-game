"""
Connect Four: Artificial Intelligence Engine Module.

Implements the Minimax algorithm with Alpha-Beta Pruning and a domain-specific
heuristic evaluation function for Connect Four.

Authors: Student-Friendly FAI Case Study Implementation
"""

import math
import time
from typing import List, Tuple, Optional
import numpy as np

from game import (
    ConnectFour,
    ROWS,
    COLS,
    EMPTY,
    PLAYER_PIECE,
    AI_PIECE,
    WINDOW_LENGTH
)

# Preferred column exploration order (center columns first to maximize Alpha-Beta cutoffs)
MOVE_ORDERING: List[int] = [3, 2, 4, 1, 5, 0, 6]


class AIPlayer:
    """
    Intelligent Connect Four agent utilizing Minimax search with Alpha-Beta Pruning.
    
    Attributes:
        depth (int): Maximum lookahead ply/depth (default: 5).
        nodes_evaluated (int): Counter for board states evaluated in the most recent search.
        pruning_cutoffs (int): Counter for subtrees pruned via alpha >= beta.
        execution_time_ms (float): Search computation duration in milliseconds.
        last_move (Optional[int]): Column index chosen by the last search.
        last_score (Optional[float]): Heuristic/terminal score of the selected move.
    """

    def __init__(self, depth: int = 5) -> None:
        self.depth: int = depth
        self.nodes_evaluated: int = 0
        self.pruning_cutoffs: int = 0
        self.execution_time_ms: float = 0.0
        self.last_move: Optional[int] = None
        self.last_score: Optional[float] = None

    def reset_stats(self) -> None:
        """Reset search metrics before evaluating a new move."""
        self.nodes_evaluated = 0
        self.pruning_cutoffs = 0
        self.execution_time_ms = 0.0
        self.last_move = None
        self.last_score = None

    def evaluate_window(self, window: List[int], piece: int) -> int:
        """
        Evaluate a 4-cell window heuristic value for the given piece.
        
        Scoring Criteria:
            - 4 of player's pieces: +100,000 (winning alignment)
            - 3 of player's pieces + 1 empty: +100 (promising 3-in-a-row)
            - 2 of player's pieces + 2 empty: +10 (developing 2-in-a-row)
            - 3 of opponent's pieces + 1 empty: -150 (threat penalty to force blocking)
            - 2 of opponent's pieces + 2 empty: -10 (opponent potential)
        """
        score = 0
        opp_piece = PLAYER_PIECE if piece == AI_PIECE else AI_PIECE

        piece_count = window.count(piece)
        empty_count = window.count(EMPTY)
        opp_count = window.count(opp_piece)

        if piece_count == 4:
            score += 100000
        elif piece_count == 3 and empty_count == 1:
            score += 100
        elif piece_count == 2 and empty_count == 2:
            score += 10

        # Opponent threat evaluation (defensive pressure)
        if opp_count == 3 and empty_count == 1:
            score -= 150
        elif opp_count == 2 and empty_count == 2:
            score -= 10

        return score

    def score_position(self, board: np.ndarray, piece: int) -> int:
        """
        Heuristic evaluation function for non-terminal board states.
        
        Evaluates:
        1. Center column control: Pieces in center column 3 possess higher strategic
           value because they participate in the maximum number of potential 4-in-a-row lines.
        2. Sub-center columns (2 and 4).
        3. All 69 possible 4-cell windows across the board:
           - 24 Horizontal windows
           - 21 Vertical windows
           - 12 Positively sloped diagonal windows (/)
           - 12 Negatively sloped diagonal windows (\\)
        """
        score = 0
        opp_piece = PLAYER_PIECE if piece == AI_PIECE else AI_PIECE

        # 1. Center Column Evaluation (Strategic Weight)
        center_array = [int(board[r][COLS // 2]) for r in range(ROWS)]
        center_count = center_array.count(piece)
        score += center_count * 6

        opp_center_count = center_array.count(opp_piece)
        score -= opp_center_count * 4

        # Sub-center column weighting (columns 2 and 4)
        for sub_col in [2, 4]:
            sub_col_array = [int(board[r][sub_col]) for r in range(ROWS)]
            score += sub_col_array.count(piece) * 2
            score -= sub_col_array.count(opp_piece) * 2

        # 2. Score Horizontal Windows
        for r in range(ROWS):
            row_array = [int(i) for i in list(board[r, :])]
            for c in range(COLS - 3):
                window = row_array[c:c + WINDOW_LENGTH]
                score += self.evaluate_window(window, piece)

        # 3. Score Vertical Windows
        for c in range(COLS):
            col_array = [int(i) for i in list(board[:, c])]
            for r in range(ROWS - 3):
                window = col_array[r:r + WINDOW_LENGTH]
                score += self.evaluate_window(window, piece)

        # 4. Score Positively Sloped Diagonals (/)
        for r in range(ROWS - 3):
            for c in range(COLS - 3):
                window = [int(board[r + i][c + i]) for i in range(WINDOW_LENGTH)]
                score += self.evaluate_window(window, piece)

        # 5. Score Negatively Sloped Diagonals (\)
        for r in range(3, ROWS):
            for c in range(COLS - 3):
                window = [int(board[r - i][c + i]) for i in range(WINDOW_LENGTH)]
                score += self.evaluate_window(window, piece)

        return score

    def order_moves(self, valid_locations: List[int]) -> List[int]:
        """
        Sort valid column moves from center outward.
        
        Ordering center columns first provides stronger candidate moves early,
        tightening the alpha and beta bounds and causing significant pruning cutoffs.
        """
        return [col for col in MOVE_ORDERING if col in valid_locations]

    def minimax(
        self,
        board: np.ndarray,
        depth: int,
        alpha: float,
        beta: float,
        maximizing_player: bool
    ) -> Tuple[Optional[int], float]:
        """
        Recursive Minimax algorithm enhanced with Alpha-Beta Pruning.
        
        Args:
            board (np.ndarray): Current Connect Four board state.
            depth (int): Remaining search depth (plies).
            alpha (float): Best score achieved so far by the maximizing player.
            beta (float): Best score achieved so far by the minimizing player.
            maximizing_player (bool): True if AI turn (maximizing), False if Human (minimizing).
            
        Returns:
            Tuple[Optional[int], float]: (Best column move, Heuristic or terminal score)
        """
        self.nodes_evaluated += 1

        valid_locations = ConnectFour.get_valid_locations(board)
        is_ai_win = ConnectFour.check_win(board, AI_PIECE)
        is_player_win = ConnectFour.check_win(board, PLAYER_PIECE)

        # Base Cases: Terminal Game States or Depth Limit Reached
        if is_ai_win:
            # Prefer immediate wins (higher remaining depth = fewer moves to victory)
            return (None, 100000000.0 + depth * 1000)
        if is_player_win:
            # Delay defeat (lower remaining depth = defeat postponed)
            return (None, -100000000.0 - depth * 1000)
        if len(valid_locations) == 0:
            # Draw game state
            return (None, 0.0)
        if depth == 0:
            # Leaf node heuristic evaluation
            return (None, float(self.score_position(board, AI_PIECE)))

        # Move ordering: inspect center columns first to maximize cutoffs
        ordered_locations = self.order_moves(valid_locations)

        if maximizing_player:
            # Maximizing Player: AI (Yellow)
            max_eval = -math.inf
            best_col = ordered_locations[0]
            best_heuristic = -math.inf

            for col in ordered_locations:
                row = ConnectFour.get_next_open_row(board, col)
                if row is None:
                    continue

                # Simulate AI move
                temp_board = ConnectFour.copy_board(board)
                ConnectFour.drop_piece(temp_board, row, col, AI_PIECE)

                # Recursive call for minimizing player
                _, evaluation = self.minimax(temp_board, depth - 1, alpha, beta, False)

                # Primary criteria: Minimax evaluation score
                # Secondary criteria (tie-breaker): Direct heuristic positional value
                if evaluation > max_eval:
                    max_eval = evaluation
                    best_col = col
                    best_heuristic = self.score_position(temp_board, AI_PIECE)
                elif evaluation == max_eval:
                    h_val = self.score_position(temp_board, AI_PIECE)
                    if h_val > best_heuristic:
                        best_col = col
                        best_heuristic = h_val

                alpha = max(alpha, evaluation)

                # Alpha-Beta Pruning condition
                if alpha >= beta:
                    self.pruning_cutoffs += 1
                    break  # Beta cutoff: Minimizer will avoid this subtree

            return (best_col, max_eval)

        else:
            # Minimizing Player: Human (Red)
            min_eval = math.inf
            best_col = ordered_locations[0]
            best_heuristic = math.inf

            for col in ordered_locations:
                row = ConnectFour.get_next_open_row(board, col)
                if row is None:
                    continue

                # Simulate Human move
                temp_board = ConnectFour.copy_board(board)
                ConnectFour.drop_piece(temp_board, row, col, PLAYER_PIECE)

                # Recursive call for maximizing player
                _, evaluation = self.minimax(temp_board, depth - 1, alpha, beta, True)

                if evaluation < min_eval:
                    min_eval = evaluation
                    best_col = col
                    best_heuristic = self.score_position(temp_board, AI_PIECE)
                elif evaluation == min_eval:
                    h_val = self.score_position(temp_board, AI_PIECE)
                    if h_val < best_heuristic:
                        best_col = col
                        best_heuristic = h_val

                beta = min(beta, evaluation)

                # Alpha-Beta Pruning condition
                if alpha >= beta:
                    self.pruning_cutoffs += 1
                    break  # Alpha cutoff: Maximizer will avoid this subtree

            return (best_col, min_eval)

    def get_best_move(self, board: np.ndarray, depth: Optional[int] = None) -> Tuple[int, float]:
        """
        Public interface to find the optimal column move for the AI.
        
        Resets performance metrics, tracks search runtime, and executes Minimax.
        
        Args:
            board (np.ndarray): The current board.
            depth (Optional[int]): Search depth override (uses self.depth if None).
            
        Returns:
            Tuple[int, float]: (Selected column index, Evaluation score)
        """
        self.reset_stats()
        search_depth = depth if depth is not None else self.depth

        start_time = time.perf_counter()
        col, score = self.minimax(
            board=board,
            depth=search_depth,
            alpha=-math.inf,
            beta=math.inf,
            maximizing_player=True
        )
        end_time = time.perf_counter()

        self.execution_time_ms = round((end_time - start_time) * 1000, 2)
        self.last_move = col
        self.last_score = score

        # Fallback to any valid column if col is None (e.g. edge condition)
        if col is None:
            valid_cols = ConnectFour.get_valid_locations(board)
            if valid_cols:
                col = self.order_moves(valid_cols)[0]
            else:
                col = 3

        return col, score
