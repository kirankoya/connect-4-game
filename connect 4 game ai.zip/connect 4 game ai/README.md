# Connect Four: An Intelligent Game Using Minimax Algorithm with Alpha-Beta Pruning

**Course:** Fundamentals of Artificial Intelligence (FAI) Case Study  
**Topic:** Adversarial Search, Game Theory, Minimax Decision Rule, Alpha-Beta Pruning, and Heuristic Evaluation  
**Language:** Python 3.10+ (Tested on Python 3.13)  
**GUI Framework:** Pygame  

---

## 1. Abstract & Problem Statement

### 1.1 Abstract
Adversarial search in two-player, zero-sum, perfect-information games represents a cornerstone of classical artificial intelligence. This project implements a fully playable, interactive Connect Four game where a human competitor (Red discs) plays against an autonomous AI opponent (Yellow discs). The AI agent formulates strategic decisions by traversing game trees using the **Minimax Algorithm** combined with **Alpha-Beta Pruning** and an informed **domain-specific heuristic evaluation function**. The graphical user interface (built with Pygame) displays real-time search metrics—including search depth, nodes evaluated, branches pruned, and decision latency—providing students and instructors with a live demonstration of adversarial search mechanics.

### 1.2 Problem Statement
Connect Four possesses a state-space complexity of approximately $4.53 \times 10^{12}$ reachable positions and a game-tree complexity of roughly $10^{21}$. Because exhaustive brute-force search to the game's termination is computationally intractable in real time on standard consumer hardware, an AI agent must:
1. Limit its search horizon to a finite depth $d$ (configurable plies).
2. Approximate the utility of non-terminal leaf states using an informed heuristic evaluation function.
3. Eliminate redundant and provably suboptimal game-tree subtrees using Alpha-Beta Pruning without altering the minimax decision.
4. Execute decisions within interactive latencies ($< 250\text{ ms}$) while preventing human victory and exploiting winning configurations.

---

## 2. Project Objectives

1. **Implement Classical Adversarial Search:** Build Minimax and Alpha-Beta Pruning from first principles in Python without relying on external game-playing libraries or random heuristics.
2. **Design an Informed Evaluation Function:** Formulate a mathematical scoring model assessing center-column control, 4-cell window patterns (two-in-a-row, three-in-a-row), and defensive threat interception.
3. **Optimize Tree Search with Move Ordering:** Implement center-outward candidate move exploration (`[3, 2, 4, 1, 5, 0, 6]`) to accelerate bound convergence and maximize $\alpha \ge \beta$ pruning cutoffs.
4. **Develop a Student-Centric GUI & HUD:** Create a Pygame interface featuring smooth disc-drop gravity animations, win-line highlights, customizable search depth selector (2 to 6 plies), and a live algorithm inspection panel.
5. **Empirical Validation:** Provide an automated unit and simulation test suite (`pytest`) verifying gravity logic, win detection, draw detection, defensive blocking, and search metric tracking.

---

## 3. Connect Four Game Formalization

Connect Four is defined as a formal zero-sum game of perfect information:

| Component | Formal Specification |
| :--- | :--- |
| **Players** | Two players: Max (AI, Yellow, $p=2$) and Min (Human, Red, $p=1$). |
| **Grid Dimensions** | $R = 6$ rows by $C = 7$ columns ($42$ total cells). |
| **Initial State ($S_0$)** | An empty $6 \times 7$ grid: $\forall (r, c), \text{board}[r][c] = 0$. |
| **Actions ($A(s)$)** | Dropping a disc into any non-full column $c \in \{0, 1, \dots, 6\}$ such that $\text{board}[R-1][c] = 0$. |
| **Transition Model ($T(s, a)$)** | Gravity-constrained drop: Disc occupies $(r, c)$, where $r = \min \{i \mid \text{board}[i][c] = 0\}$. |
| **Terminal Test ($Terminal(s)$)** | Either player aligns 4 consecutive discs (horizontal, vertical, or diagonal), or all 42 cells are filled. |
| **Utility Function ($U(s)$)** | $+100,000,000$ for AI win, $-100,000,000$ for Human win, $0$ for Draw. |

```
Standard Connect Four Grid (6 Rows x 7 Columns):

 Row 5 [ .  .  .  .  .  .  . ]  <- Top row (Column full when this row is occupied)
 Row 4 [ .  .  .  .  .  .  . ]
 Row 3 [ .  .  .  .  .  .  . ]
 Row 2 [ .  .  .  .  .  .  . ]
 Row 1 [ .  .  .  .  .  .  . ]
 Row 0 [ .  .  .  .  .  .  . ]  <- Bottom row (First piece lands here)
        Col Col Col Col Col Col Col
         0   1   2   3   4   5   6
```

---

## 4. Why AI is Required for Connect Four

Human players rely on pattern recognition, spatial foresight, and trap anticipation (such as creating double-threat "forks"). A random or greedy agent fails because:
- **Lookahead Horizon:** An immediate move might look attractive but allow the opponent a counter-strike win on the next turn.
- **Trap Defense:** Without looking at least 2 to 4 plies ahead, an agent cannot anticipate multi-turn setups like vertical columns or diagonal staircases.
- **Strategic Center Dominance:** Discs placed in column 3 participate in up to 13 distinct 4-in-a-row combinations, whereas discs in edge columns (0 and 6) participate in only 3 or 4.

Classical adversarial search guarantees that the AI selects the mathematically optimal move under the assumption of optimal play by the opponent.

---

## 5. The Minimax Algorithm

### 5.1 Principle of Minimax
Minimax computes the optimal strategy for a maximizing player in a zero-sum game where both players make rational, optimal choices:
- **Maximizer (AI):** Aims to maximize the evaluation score.
- **Minimizer (Human):** Aims to minimize the AI's score (maximize human advantage).

### 5.2 Mathematical Recurrence
For a game state $s$ at search depth $d$:

$$\text{Minimax}(s, d) = \begin{cases}
U(s) & \text{if } Terminal(s) \\
H(s) & \text{if } d = 0 \\
\max_{a \in A(s)} \text{Minimax}(Result(s, a), d - 1) & \text{if Player}(s) = \text{AI (Max)} \\
\min_{a \in A(s)} \text{Minimax}(Result(s, a), d - 1) & \text{if Player}(s) = \text{Human (Min)}
\end{cases}$$

Where $U(s)$ is the terminal utility, $H(s)$ is the heuristic evaluation score, and $Result(s, a)$ is the state resulting from applying action $a$.

```
                     [ MAX Node (AI's Turn) ]
                     /          |           \
               Move 0        Move 3        Move 6
               /                |                \
    [ MIN Node ]          [ MIN Node ]          [ MIN Node ]
      /      \              /      \              /      \
   ...        ...        ...        ...        ...        ...
```

---

## 6. Alpha-Beta Pruning

### 6.1 Purpose and Definition
Plain Minimax evaluates every node in the game tree down to depth $d$, leading to an exponential explosion of $O(b^d)$ nodes. **Alpha-Beta Pruning** is an algorithmic optimization that returns the exact same mathematical minimax decision while skipping branches that cannot influence the final outcome.

Two bounding variables are propagated through the search tree:
- **$\alpha$ (Alpha):** The best (highest) value that the **Maximizer** is guaranteed to achieve so far along the path to the root. Initially $-\infty$.
- **$\beta$ (Beta):** The best (lowest) value that the **Minimizer** is guaranteed to achieve so far along the path to the root. Initially $+\infty$.

### 6.2 Pruning Cutoff Rule
At any node:
$$\text{If } \alpha \ge \beta, \quad \text{PRUNE (Terminate branch loop)}$$

- **Beta Cutoff (in Maximizer):** The maximizer finds a move with evaluation $\ge \beta$. Because the parent minimizer already has a route guaranteeing a score $\le \beta$, the minimizer will never allow play to reach this subtree.
- **Alpha Cutoff (in Minimizer):** The minimizer finds a move with evaluation $\le \alpha$. Because the parent maximizer already has a route guaranteeing a score $\ge \alpha$, the maximizer will never pick this branch.

### 6.3 Move Ordering Optimization
The efficiency of Alpha-Beta pruning depends heavily on child node exploration order:
- **Worst-case ordering:** Descending order for Min, ascending for Max $\implies O(b^d)$ (no pruning).
- **Optimal ordering:** Best moves evaluated first $\implies O(b^{d/2})$.
- **Connect Four Implementation:** Columns are explored from the center outward:
  $$\text{MOVE\_ORDERING} = [3, 2, 4, 1, 5, 0, 6]$$
  Because center moves establish strong alpha/beta bounds early, this reduces evaluated nodes by $60\%\text{ to }80\%$ compared to left-to-right traversal.

---

## 7. Heuristic Evaluation Function

When the search reaches its configured depth limit ($d = 0$) without encountering a terminal state, an evaluation function $H(s)$ approximates board quality.

### 7.1 Mathematical Structure
The board evaluation combines center-column strategic weighting with sliding 4-cell window analysis across all 69 possible quadruplets on the $6 \times 7$ grid:

$$H(s) = W_{\text{center}} \cdot \Delta C + \sum_{k=1}^{69} \text{EvaluateWindow}(W_k)$$

### 7.2 Window Decomposition (69 Total Windows)
1. **Horizontal Windows:** 6 rows $\times$ 4 windows/row = $24$ windows.
2. **Vertical Windows:** 7 columns $\times$ 3 windows/col = $21$ windows.
3. **Positive Diagonals (/):** 3 rows $\times$ 4 cols = $12$ windows.
4. **Negative Diagonals (\\):** 3 rows $\times$ 4 cols = $12$ windows.

### 7.3 Scoring Matrix
| Window Composition | AI (Maximizer) Score | Human (Opponent Threat) Score | Rationale |
| :--- | :---: | :---: | :--- |
| **4 discs in window** | $+100,000$ | $-100,000$ | Terminal / Decisive win |
| **3 discs + 1 empty slot** | $+100$ | $-150$ | High threat. Opponent 3-in-a-row is penalized more heavily ($-150$) to force defensive blocks. |
| **2 discs + 2 empty slots** | $+10$ | $-10$ | Developing offensive/defensive potential |
| **Center Column (Col 3)** | $+6$ per disc | $-4$ per disc | Center discs open the greatest number of winning lines |
| **Sub-center (Cols 2, 4)** | $+2$ per disc | $-2$ per disc | Flanking strategic influence |

---

## 8. Step-by-Step Worked Example of Alpha-Beta Pruning

Consider a simplified subtree search at depth $d=2$ with initial bounds $\alpha = -\infty, \beta = +\infty$:

```
                       [ MAX Node (Root) ]  α=-∞, β=+∞
                       /                 \
             Branch A (Col 3)         Branch B (Col 2)
             /                              \
   [ MIN Node A ]                   [ MIN Node B ]
    α=-∞, β=+∞                       α=40, β=+∞
    /          \                     /          \
 Leaf A1      Leaf A2             Leaf B1      Leaf B2
 Score = 40   Score = 60          Score = 20   [PRUNED!]
```

### Walkthrough Steps:
1. **Explore Branch A (Col 3):**
   - Traverse down to **MIN Node A**. Bounds inherited: $\alpha = -\infty, \beta = +\infty$.
   - Evaluate **Leaf A1**: Returns score $+40$.
   - MIN updates its upper bound: $\beta = \min(+\infty, 40) = 40$.
   - Evaluate **Leaf A2**: Returns score $+60$.
   - MIN updates: $\beta = \min(40, 60) = 40$.
   - MIN Node A finishes with value $\mathbf{40}$.
2. **Back at Root (MAX):**
   - Root updates its lower bound: $\alpha = \max(-\infty, 40) = \mathbf{40}$.
   - The Root now knows it can achieve at least $40$ by choosing Col 3.
3. **Explore Branch B (Col 2):**
   - Traverse down to **MIN Node B**. Bounds inherited: $\alpha = 40, \beta = +\infty$.
   - Evaluate **Leaf B1**: Returns score $+20$.
   - MIN updates its upper bound: $\beta = \min(+\infty, 20) = \mathbf{20}$.
   - **Pruning Check:** At this point, $\alpha = 40$ and $\beta = 20$.
   - Condition $\alpha \ge \beta$ ($40 \ge 20$) is **TRUE**!
   - **Beta Cutoff Occurs:** Leaf B2 is **PRUNED**!
4. **Conclusion:**
   - The AI skips evaluating Leaf B2 because MIN would choose Leaf B1 ($20$), which is worse for MAX than the guaranteed $40$ from Branch A.
   - Root chooses **Col 3** with score $40$.

---

## 9. Algorithms Pseudocode

### 9.1 Minimax with Alpha-Beta Pruning Pseudocode

```text
function MINIMAX(board, depth, alpha, beta, maximizing_player):
    if is_terminal(board) or depth == 0:
        return (None, evaluate_or_terminal_utility(board, depth))

    ordered_columns = order_moves_by_center(get_valid_columns(board))

    if maximizing_player:
        max_eval = -INFINITY
        best_col = ordered_columns[0]
        
        for col in ordered_columns:
            temp_board = simulate_drop(board, col, AI_PIECE)
            _, evaluation = MINIMAX(temp_board, depth - 1, alpha, beta, False)
            
            if evaluation > max_eval:
                max_eval = evaluation
                best_col = col
            
            alpha = max(alpha, evaluation)
            if alpha >= beta:
                pruning_cutoffs += 1
                break  // Beta cutoff
                
        return (best_col, max_eval)

    else: // Minimizing player (Human)
        min_eval = +INFINITY
        best_col = ordered_columns[0]
        
        for col in ordered_columns:
            temp_board = simulate_drop(board, col, PLAYER_PIECE)
            _, evaluation = MINIMAX(temp_board, depth - 1, alpha, beta, True)
            
            if evaluation < min_eval:
                min_eval = evaluation
                best_col = col
                
            beta = min(beta, evaluation)
            if alpha >= beta:
                pruning_cutoffs += 1
                break  // Alpha cutoff
                
        return (best_col, min_eval)
```

---

## 10. Complexity Analysis

| Metric | Plain Minimax | Alpha-Beta Pruning (Optimal Move Order) | Connect Four Value |
| :--- | :---: | :---: | :--- |
| **Time Complexity** | $O(b^d)$ | $O(b^{d/2})$ | $b \le 7$, $d = 5 \implies \approx 16,807$ down to $\approx 350-1,200$ nodes |
| **Space Complexity** | $O(b \cdot d)$ | $O(b \cdot d)$ | Linear recursion stack depth ($d \le 6$) |
| **Effective Branching Factor** | $b \approx 7$ | $b_{\text{eff}} \approx \sqrt{7} \approx 2.65$ | Drastic reduction in real runtime |

---

## 11. Comparison: Minimax vs. Alpha-Beta Pruning

| Feature | Plain Minimax | Minimax with Alpha-Beta Pruning |
| :--- | :--- | :--- |
| **Search Tree Traversal** | Evaluates 100% of nodes to depth $d$. | Skips provably non-influential subtrees. |
| **Decision Output** | Optimal minimax move. | **Identical** optimal minimax move. |
| **Average Node Count ($d=5$)** | $\sim 16,807$ nodes. | $\sim 800 - 3,500$ nodes (up to $80\%$ reduction). |
| **Search Speed** | Noticeable delay on depth $\ge 5$. | Instantaneous execution ($< 150\text{ ms}$). |
| **Move Ordering Impact** | Has no effect on node count. | Essential: center-outward order maximizes cutoffs. |

---

## 12. Classical AI vs. Machine Learning

A common viva interview question is: *"Is Minimax a Machine Learning algorithm?"*

**Answer: No. Minimax with Alpha-Beta Pruning is a Classical Adversarial Search (Symbolic AI) algorithm.**

| Dimension | Classical Adversarial Search (Minimax) | Machine Learning / Deep RL (e.g., AlphaZero) |
| :--- | :--- | :--- |
| **Paradigm** | Deterministic search through state space. | Statistical approximation / pattern learning. |
| **Training Data** | Requires **no** dataset or training phase. | Requires millions of self-play training games. |
| **Decision Mechanism** | Recursive game-tree expansion and heuristics. | Neural network forward pass with policy/value heads. |
| **Explainability** | **100% transparent**: Every node, alpha, and beta bound can be traced. | Black-box latent weights; hard to interpret individual decisions. |
| **Optimality Guarantee** | Mathematically optimal up to the searched horizon. | Empirical approximation; susceptible to hallucinations/blindspots. |

---

## 13. Project Structure

```
ConnectFourAI/
├── main.py              # Pygame GUI, event loop, animations, HUD panel & turn manager
├── game.py              # ConnectFour rules engine, board state, gravity, win/draw detection
├── ai.py                # Minimax, Alpha-Beta pruning, heuristic evaluation & metrics tracker
├── requirements.txt     # Python dependencies (pygame, numpy, pytest)
├── pytest.ini           # Pytest discovery configuration
├── conftest.py          # Root-level test import configuration
├── README.md            # Comprehensive FAI case study documentation
└── tests/
    ├── test_game.py     # 9 tests: Board gravity, column boundaries, 4 win directions, draw
    ├── test_ai.py       # 10 tests: Immediate win, blocking, pruning cutoffs, center bias
    └── test_simulation.py # 3 tests: Full simulated matches, variable depths, restart flow
```

---

## 14. Installation & Execution

### 14.1 Prerequisites
- Python 3.10, 3.11, 3.12, or 3.13 installed.
- Pip package manager.

### 14.2 Install Dependencies
Open your command terminal in the project directory and run:

```bash
pip install -r requirements.txt
```

*Contents of `requirements.txt`:*
```
pygame>=2.6.0
numpy>=1.24.0
pytest>=8.0.0
```

### 14.3 Launch the Game
Run the Pygame application:

```bash
python main.py
```

### 14.4 Running Automated Tests
Run the test suite with verbose reporting:

```bash
pytest -v
```

---

## 15. Automated Test Suite & Validation Results

The project includes 22 automated tests covering all game and search behaviors. All 22 tests pass:

```text
============================= test session starts =============================
platform win32 -- Python 3.13.5, pytest-8.3.4
collected 22 items

tests/test_ai.py::test_ai_takes_immediate_horizontal_win PASSED          [  4%]
tests/test_ai.py::test_ai_takes_immediate_vertical_win PASSED            [  9%]
tests/test_ai.py::test_ai_takes_diagonal_win PASSED                      [ 13%]
tests/test_ai.py::test_ai_blocks_immediate_horizontal_human_win PASSED   [ 18%]
tests/test_ai.py::test_ai_blocks_immediate_vertical_human_win PASSED     [ 22%]
tests/test_ai.py::test_ai_blocks_diagonal_human_win PASSED               [ 27%]
tests/test_ai.py::test_alpha_beta_pruning_execution PASSED               [ 31%]
tests/test_ai.py::test_center_column_preference_on_empty_board PASSED    [ 36%]
tests/test_ai.py::test_move_ordering_structure PASSED                    [ 40%]
tests/test_ai.py::test_stats_reset PASSED                                [ 45%]
tests/test_game.py::test_board_initialization PASSED                     [ 50%]
tests/test_game.py::test_drop_piece_and_gravity PASSED                   [ 54%]
tests/test_game.py::test_full_column_rejection PASSED                    [ 59%]
tests/test_game.py::test_horizontal_win PASSED                           [ 63%]
tests/test_game.py::test_vertical_win PASSED                             [ 68%]
tests/test_game.py::test_positive_diagonal_win PASSED                    [ 72%]
tests/test_game.py::test_negative_diagonal_win PASSED                    [ 77%]
tests/test_game.py::test_draw_condition PASSED                           [ 81%]
tests/test_game.py::test_reset_game PASSED                               [ 86%]
tests/test_simulation.py::test_full_game_simulation PASSED               [ 90%]
tests/test_simulation.py::test_ai_handles_various_depths PASSED          [ 95%]
tests/test_simulation.py::test_restart_flow PASSED                       [100%]

============================= 22 passed in 0.69s ==============================
```

---

## 16. Graphical User Interface Features

1. **Board Canvas:** $7 \times 6$ circular slots rendered with 3D disc highlights and shadow bevels.
2. **Disc Drop Animation:** Physics-based gravity acceleration (~15 frames) for every disc dropped.
3. **Hover Preview:** Red hover disc tracks the mouse along the top row before the player drops it.
4. **Win Highlighter:** Pulsing cyan rings around the 4 winning discs connected by a glowing line.
5. **Demonstration HUD Panel:**
   - **Current Status:** Displays whose turn it is or announces the winner / draw.
   - **Search Depth:** Displays current lookahead ply (2, 4, 5, or 6).
   - **Nodes Evaluated:** Real-time count of board states traversed in the last search.
   - **Pruned Branches:** Real-time count of subtrees pruned where $\alpha \ge \beta$.
   - **Compute Time:** Search latency in milliseconds.
   - **AI Selected Column:** Exact column index chosen.
   - **Position Score:** Numerical heuristic evaluation of the chosen move.
6. **Interactive Controls:**
   - `Restart Game`: Instantly clears board and resets metrics.
   - `Play Again`: Highlighted upon game completion.
   - `Let AI Make Move`: Lets the AI take the opening move or make consecutive moves.
   - `Difficulty Buttons [D:2, D:4, D:5, D:6]`: Dynamic depth adjustment during viva demonstrations.

---

## 17. College Viva Voce Questions & Model Answers

### Q1: What is the significance of the initial bounds $\alpha = -\infty$ and $\beta = +\infty$?
**Answer:** Alpha represents the highest score the Maximizer can guarantee; initially, no moves have been explored, so its baseline is $-\infty$. Beta represents the lowest score the Minimizer can guarantee; initially, its baseline is $+\infty$. As search proceeds, $\alpha$ only increases and $\beta$ only decreases.

### Q2: Does Alpha-Beta Pruning change the move that Minimax selects?
**Answer:** No. Alpha-Beta Pruning is mathematically proven to produce the identical minimax score and move as exhaustive Minimax. It only prunes branches that are mathematically provable to be ignored by rational players.

### Q3: Why is move ordering crucial in Alpha-Beta Pruning?
**Answer:** If the best moves are explored first, $\alpha$ rises quickly and $\beta$ drops quickly, narrowing the window $[\alpha, \beta]$ and triggering cutoffs earlier. In Connect Four, testing center columns first yields effective branching factor $b_{\text{eff}} \approx 2.65$ instead of $7$.

### Q4: How does the heuristic function ensure the AI blocks opponent wins?
**Answer:** When evaluating 4-cell windows, having 3 opponent discs and 1 empty cell carries a negative penalty of $-150$, whereas having 3 of its own discs awards $+100$. Because avoiding defeat is weighted higher, Minimax prioritizes blocking moves over secondary developments. Terminal checks also award $+100,000,000 + depth$ for wins and $-100,000,000 - depth$ for losses to favor immediate wins and delay losses.

### Q5: What is the horizon effect?
**Answer:** The horizon effect occurs when a damaging opponent threat is pushed past the maximum search depth $d$, causing the AI to mistakenly believe it has avoided the threat when it has merely postponed it. Setting depth to 5 or 6 plies prevents this in most tactical Connect Four scenarios.

---

## 18. References & Academic Context
1. Russell, S., & Norvig, P. (2020). *Artificial Intelligence: A Modern Approach* (4th ed.). Pearson. Chapter 5: Adversarial Search and Games.
2. Knuth, D. E., & Moore, R. W. (1975). An analysis of alpha-beta pruning. *Artificial Intelligence*, 6(4), 293-326.
3. Allis, L. V. (1988). *A Knowledge-based Approach of Connect-Four: The Game is Solved: White Wins*. Vrije Universiteit Amsterdam.
