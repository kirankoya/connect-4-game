"""
Connect Four: Main Application and Pygame User Interface.

Provides an interactive GUI with an animated Connect Four board, real-time
search statistics, AI algorithm inspection HUD, and configurable search depths.

Authors: Student-Friendly FAI Case Study Implementation
"""

import sys
import math
import time
from typing import List, Tuple, Optional
import pygame
import numpy as np

from game import (
    ConnectFour,
    ROWS,
    COLS,
    EMPTY,
    PLAYER_PIECE,
    AI_PIECE
)
from ai import AIPlayer

# ---------------------------------------------------------
# CONSTANTS & CONFIGURATION
# ---------------------------------------------------------
SQUARESIZE: int = 100
BOARD_WIDTH: int = COLS * SQUARESIZE        # 700 px
BOARD_HEIGHT: int = (ROWS + 1) * SQUARESIZE # 700 px (Row 0 reserved for hover preview)
PANEL_WIDTH: int = 380                      # Metrics & controls sidebar
WINDOW_WIDTH: int = BOARD_WIDTH + PANEL_WIDTH # 1080 px
WINDOW_HEIGHT: int = BOARD_HEIGHT           # 700 px
RADIUS: int = int(SQUARESIZE / 2 - 8)       # Disc radius (42 px)

# Color Palette (Modern Dark / Neon Aesthetic)
COLOR_BG = (15, 23, 42)             # Deep Navy Slate (#0F172A)
COLOR_BOARD = (30, 58, 138)         # Royal Blue Board (#1E3A8A)
COLOR_BOARD_RIM = (23, 37, 84)      # Dark Blue Bevel (#172554)
COLOR_EMPTY = (15, 23, 42)          # Empty slot background
COLOR_PLAYER = (239, 68, 68)        # Human Disc: Crimson Red (#EF4444)
COLOR_PLAYER_HOVER = (239, 68, 68, 180)
COLOR_AI = (250, 204, 21)           # AI Disc: Gold Yellow (#FACC15)
COLOR_WIN_HIGHLIGHT = (56, 189, 248) # Cyan Win Glow (#38BDF8)
COLOR_PANEL_BG = (24, 33, 53)       # Sidebar Panel Background
COLOR_CARD_BG = (30, 41, 59)        # HUD Metric Card Background (#1E293B)
COLOR_CARD_BORDER = (51, 65, 85)    # Card Border (#334155)
COLOR_TEXT_MAIN = (248, 250, 252)   # High Contrast White
COLOR_TEXT_MUTED = (148, 163, 184)  # Muted Gray (#94A3B8)
COLOR_ACCENT = (14, 165, 233)       # Bright Sky Blue

# ---------------------------------------------------------
# INTERACTIVE UI BUTTON COMPONENT
# ---------------------------------------------------------
class Button:
    """Reusable interactive button with hover and click state handling."""

    def __init__(
        self,
        rect: Tuple[int, int, int, int],
        text: str,
        base_color: Tuple[int, int, int],
        hover_color: Tuple[int, int, int],
        text_color: Tuple[int, int, int] = COLOR_TEXT_MAIN,
        font_size: int = 18
    ) -> None:
        self.rect = pygame.Rect(rect)
        self.text = text
        self.base_color = base_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.font = pygame.font.SysFont("segoeui", font_size, bold=True)
        self.is_hovered = False

    def check_hover(self, mouse_pos: Tuple[int, int]) -> None:
        self.is_hovered = self.rect.collidepoint(mouse_pos)

    def is_clicked(self, mouse_pos: Tuple[int, int]) -> bool:
        return self.rect.collidepoint(mouse_pos)

    def draw(self, surface: pygame.Surface) -> None:
        color = self.hover_color if self.is_hovered else self.base_color
        pygame.draw.rect(surface, color, self.rect, border_radius=8)
        pygame.draw.rect(surface, COLOR_CARD_BORDER, self.rect, width=1, border_radius=8)

        text_surf = self.font.render(self.text, True, self.text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)


# ---------------------------------------------------------
# DRAWING HELPERS
# ---------------------------------------------------------
def draw_board(
    screen: pygame.Surface,
    board: np.ndarray,
    winning_coords: Optional[List[Tuple[int, int]]] = None
) -> None:
    """
    Renders the Connect Four physical board, slots, discs, and win highlights.
    
    Row 0 is the bottom row of the board physically, displayed at y = (ROWS * SQUARESIZE).
    Row 5 is the top row, displayed at y = SQUARESIZE.
    """
    # Draw board blue backing
    board_rect = pygame.Rect(0, SQUARESIZE, BOARD_WIDTH, ROWS * SQUARESIZE)
    pygame.draw.rect(screen, COLOR_BOARD, board_rect)
    pygame.draw.rect(screen, COLOR_BOARD_RIM, board_rect, width=4)

    # Draw individual slots and pieces
    for c in range(COLS):
        for r in range(ROWS):
            # Center coordinates for slot (c, r)
            # Physical row 0 is at bottom (y = (ROWS - r) * SQUARESIZE + SQUARESIZE/2)
            center_x = int(c * SQUARESIZE + SQUARESIZE / 2)
            center_y = int((ROWS - r) * SQUARESIZE + SQUARESIZE / 2)

            piece = board[r][c]
            if piece == EMPTY:
                # Beveled empty circular cutout
                pygame.draw.circle(screen, COLOR_BOARD_RIM, (center_x, center_y), RADIUS + 2)
                pygame.draw.circle(screen, COLOR_EMPTY, (center_x, center_y), RADIUS)
            elif piece == PLAYER_PIECE:
                # Human Red Disc with subtle 3D highlight
                pygame.draw.circle(screen, (153, 27, 27), (center_x, center_y), RADIUS)
                pygame.draw.circle(screen, COLOR_PLAYER, (center_x, center_y), RADIUS - 3)
                pygame.draw.circle(screen, (252, 165, 165), (center_x - 10, center_y - 10), RADIUS // 4)
            elif piece == AI_PIECE:
                # AI Yellow Disc with subtle 3D highlight
                pygame.draw.circle(screen, (161, 98, 7), (center_x, center_y), RADIUS)
                pygame.draw.circle(screen, COLOR_AI, (center_x, center_y), RADIUS - 3)
                pygame.draw.circle(screen, (254, 240, 138), (center_x - 10, center_y - 10), RADIUS // 4)

    # Highlight winning discs with glowing rings and line
    if winning_coords and len(winning_coords) == 4:
        points = []
        for r, c in winning_coords:
            cx = int(c * SQUARESIZE + SQUARESIZE / 2)
            cy = int((ROWS - r) * SQUARESIZE + SQUARESIZE / 2)
            points.append((cx, cy))
            # Glowing double ring around winning discs
            pygame.draw.circle(screen, COLOR_WIN_HIGHLIGHT, (cx, cy), RADIUS + 4, width=4)
            pygame.draw.circle(screen, (255, 255, 255), (cx, cy), RADIUS - 1, width=2)

        # Connecting victory line
        pygame.draw.line(screen, COLOR_WIN_HIGHLIGHT, points[0], points[3], width=6)
        pygame.draw.line(screen, (255, 255, 255), points[0], points[3], width=2)


def draw_hover_disc(
    screen: pygame.Surface,
    hover_col: Optional[int],
    turn: int,
    game_over: bool
) -> None:
    """Draws preview disc in top row following human mouse cursor."""
    # Clear top row area
    top_area = pygame.Rect(0, 0, BOARD_WIDTH, SQUARESIZE)
    pygame.draw.rect(screen, COLOR_BG, top_area)

    if not game_over and turn == PLAYER_PIECE and hover_col is not None and 0 <= hover_col < COLS:
        center_x = int(hover_col * SQUARESIZE + SQUARESIZE / 2)
        center_y = int(SQUARESIZE / 2)
        pygame.draw.circle(screen, (153, 27, 27), (center_x, center_y), RADIUS)
        pygame.draw.circle(screen, COLOR_PLAYER, (center_x, center_y), RADIUS - 3)
        pygame.draw.circle(screen, (252, 165, 165), (center_x - 10, center_y - 10), RADIUS // 4)


def animate_disc_drop(
    screen: pygame.Surface,
    board: np.ndarray,
    col: int,
    target_row: int,
    piece: int,
    ai_info_callback
) -> None:
    """Smooth falling animation for discs dropping into the grid."""
    start_y = SQUARESIZE / 2
    target_y = (ROWS - target_row) * SQUARESIZE + SQUARESIZE / 2
    center_x = col * SQUARESIZE + SQUARESIZE / 2

    clock = pygame.time.Clock()
    current_y = start_y
    velocity = 4.0
    gravity = 3.2

    disc_color = COLOR_PLAYER if piece == PLAYER_PIECE else COLOR_AI
    shadow_color = (153, 27, 27) if piece == PLAYER_PIECE else (161, 98, 7)
    highlight_color = (252, 165, 165) if piece == PLAYER_PIECE else (254, 240, 138)

    while current_y < target_y:
        current_y += velocity
        velocity += gravity

        if current_y > target_y:
            current_y = target_y

        # Redraw
        screen.fill(COLOR_BG)
        draw_board(screen, board)

        # Draw dropping disc
        pygame.draw.circle(screen, shadow_color, (int(center_x), int(current_y)), RADIUS)
        pygame.draw.circle(screen, disc_color, (int(center_x), int(current_y)), RADIUS - 3)
        pygame.draw.circle(screen, highlight_color, (int(center_x - 10), int(current_y - 10)), RADIUS // 4)

        # Draw HUD panel
        ai_info_callback()

        pygame.display.update()
        clock.tick(60)


# ---------------------------------------------------------
# INFORMATION & METRICS SIDEBAR PANEL
# ---------------------------------------------------------
def draw_info_panel(
    screen: pygame.Surface,
    game: ConnectFour,
    ai: AIPlayer,
    turn: int,
    game_over: bool,
    winner: Optional[int],
    buttons: dict,
    current_depth: int,
    ai_status_text: str = ""
) -> None:
    """
    Renders the FAI Case Study Demonstration HUD panel.
    Displays search depth, nodes evaluated, branches pruned,
    search time, current turn, and control buttons.
    """
    panel_rect = pygame.Rect(BOARD_WIDTH, 0, PANEL_WIDTH, WINDOW_HEIGHT)
    pygame.draw.rect(screen, COLOR_PANEL_BG, panel_rect)
    pygame.draw.line(screen, COLOR_CARD_BORDER, (BOARD_WIDTH, 0), (BOARD_WIDTH, WINDOW_HEIGHT), width=2)

    font_title = pygame.font.SysFont("segoeui", 22, bold=True)
    font_subtitle = pygame.font.SysFont("segoeui", 14)
    font_section = pygame.font.SysFont("segoeui", 16, bold=True)
    font_stat_val = pygame.font.SysFont("segoeui", 20, bold=True)
    font_stat_lbl = pygame.font.SysFont("segoeui", 13)
    font_badge = pygame.font.SysFont("segoeui", 13, bold=True)

    # 1. Header Section
    y = 20
    title_surf = font_title.render("Connect Four AI", True, COLOR_TEXT_MAIN)
    screen.blit(title_surf, (BOARD_WIDTH + 24, y))
    y += 28

    subtitle_surf = font_subtitle.render("Minimax with Alpha-Beta Pruning", True, COLOR_ACCENT)
    screen.blit(subtitle_surf, (BOARD_WIDTH + 24, y))
    y += 35

    # 2. Game Status Card
    status_card = pygame.Rect(BOARD_WIDTH + 20, y, PANEL_WIDTH - 40, 68)
    pygame.draw.rect(screen, COLOR_CARD_BG, status_card, border_radius=10)
    pygame.draw.rect(screen, COLOR_CARD_BORDER, status_card, width=1, border_radius=10)

    status_lbl = font_stat_lbl.render("CURRENT STATUS", True, COLOR_TEXT_MUTED)
    screen.blit(status_lbl, (BOARD_WIDTH + 32, y + 10))

    if game_over:
        if winner == PLAYER_PIECE:
            status_str = "You Won! (Red)"
            status_color = COLOR_PLAYER
        elif winner == AI_PIECE:
            status_str = "AI Won! (Yellow)"
            status_color = COLOR_AI
        else:
            status_str = "Game Ended in Draw!"
            status_color = COLOR_TEXT_MAIN
    else:
        if ai_status_text:
            status_str = ai_status_text
            status_color = COLOR_AI
        elif turn == PLAYER_PIECE:
            status_str = "Your Turn (Red Disc)"
            status_color = COLOR_PLAYER
        else:
            status_str = "AI Calculating Move..."
            status_color = COLOR_AI

    status_val = font_section.render(status_str, True, status_color)
    screen.blit(status_val, (BOARD_WIDTH + 32, y + 32))
    y += 82

    # 3. AI Search Metrics Card (Requirement 7)
    metrics_card = pygame.Rect(BOARD_WIDTH + 20, y, PANEL_WIDTH - 40, 240)
    pygame.draw.rect(screen, COLOR_CARD_BG, metrics_card, border_radius=10)
    pygame.draw.rect(screen, COLOR_CARD_BORDER, metrics_card, width=1, border_radius=10)

    hud_title = font_section.render("AI Search Demonstration HUD", True, COLOR_TEXT_MAIN)
    screen.blit(hud_title, (BOARD_WIDTH + 32, y + 12))

    # Grid of stats
    stats = [
        ("Search Depth", f"{current_depth} Plies", COLOR_ACCENT),
        ("Nodes Evaluated", f"{ai.nodes_evaluated:,}", COLOR_TEXT_MAIN),
        ("Pruned Branches (α ≥ β)", f"{ai.pruning_cutoffs:,}", (34, 197, 94)),
        ("Compute Time", f"{ai.execution_time_ms} ms", COLOR_TEXT_MAIN),
        ("AI Selected Column", f"Col {ai.last_move}" if ai.last_move is not None else "Pending", COLOR_AI),
        ("Position Score", f"{int(ai.last_score)}" if ai.last_score is not None else "0", COLOR_TEXT_MUTED)
    ]

    stat_y = y + 42
    for i, (label, val, color) in enumerate(stats):
        row_y = stat_y + i * 31
        lbl_surf = font_stat_lbl.render(label + ":", True, COLOR_TEXT_MUTED)
        val_surf = font_badge.render(val, True, color)
        screen.blit(lbl_surf, (BOARD_WIDTH + 32, row_y))
        screen.blit(val_surf, (BOARD_WIDTH + 230, row_y))

    y += 254

    # 4. Difficulty / Depth Selector
    depth_lbl = font_stat_lbl.render("SELECT SEARCH DEPTH (DIFFICULTY)", True, COLOR_TEXT_MUTED)
    screen.blit(depth_lbl, (BOARD_WIDTH + 24, y))
    y += 24

    buttons["depth_2"].draw(screen)
    buttons["depth_4"].draw(screen)
    buttons["depth_5"].draw(screen)
    buttons["depth_6"].draw(screen)

    # Highlight currently selected depth
    depth_key_map = {2: "depth_2", 4: "depth_4", 5: "depth_5", 6: "depth_6"}
    if current_depth in depth_key_map:
        active_btn = buttons[depth_key_map[current_depth]]
        pygame.draw.rect(screen, COLOR_ACCENT, active_btn.rect, width=2, border_radius=8)

    y += 50

    # 5. Action Buttons (Restart & Play Again)
    buttons["restart"].draw(screen)
    y += 52

    if game_over:
        buttons["play_again"].draw(screen)
        y += 52
    else:
        buttons["ai_first"].draw(screen)
        y += 52

    # 6. Educational Viva Note
    note_card = pygame.Rect(BOARD_WIDTH + 20, y, PANEL_WIDTH - 40, 76)
    pygame.draw.rect(screen, (15, 23, 42), note_card, border_radius=8)
    pygame.draw.rect(screen, COLOR_CARD_BORDER, note_card, width=1, border_radius=8)

    note_title = font_badge.render("FAI Algorithm Note:", True, COLOR_ACCENT)
    note_line1 = font_stat_lbl.render("Pruning condition: α ≥ β skips branches", True, COLOR_TEXT_MUTED)
    note_line2 = font_stat_lbl.render("without altering optimal Minimax decision.", True, COLOR_TEXT_MUTED)

    screen.blit(note_title, (BOARD_WIDTH + 30, y + 8))
    screen.blit(note_line1, (BOARD_WIDTH + 30, y + 28))
    screen.blit(note_line2, (BOARD_WIDTH + 30, y + 48))


# ---------------------------------------------------------
# MAIN GAME LOOP
# ---------------------------------------------------------
def main() -> None:
    """Initialize Pygame and run the primary event-driven game loop."""
    pygame.init()
    pygame.display.set_caption("Connect Four AI - Minimax with Alpha-Beta Pruning (FAI Case Study)")

    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    clock = pygame.time.Clock()

    game = ConnectFour()
    ai = AIPlayer(depth=5)

    turn = PLAYER_PIECE  # Player 1 (Red/Human) starts by default
    game_over = False
    winner: Optional[int] = None
    winning_coords: List[Tuple[int, int]] = []
    hover_col: Optional[int] = None
    current_depth = 5
    ai_status_text = ""

    # Initialize Buttons
    btn_y = 480
    buttons = {
        "depth_2": Button((BOARD_WIDTH + 20, 396, 75, 34), "D: 2", (51, 65, 85), (71, 85, 105), font_size=14),
        "depth_4": Button((BOARD_WIDTH + 105, 396, 75, 34), "D: 4", (51, 65, 85), (71, 85, 105), font_size=14),
        "depth_5": Button((BOARD_WIDTH + 190, 396, 75, 34), "D: 5", (51, 65, 85), (71, 85, 105), font_size=14),
        "depth_6": Button((BOARD_WIDTH + 275, 396, 85, 34), "D: 6", (51, 65, 85), (71, 85, 105), font_size=14),
        "restart": Button((BOARD_WIDTH + 20, 442, PANEL_WIDTH - 40, 42), "Restart Game", (225, 29, 72), (244, 63, 94)),
        "play_again": Button((BOARD_WIDTH + 20, 494, PANEL_WIDTH - 40, 42), "Play Again", (16, 185, 129), (34, 197, 94)),
        "ai_first": Button((BOARD_WIDTH + 20, 494, PANEL_WIDTH - 40, 42), "Let AI Make Move", (59, 130, 246), (96, 165, 250), font_size=16)
    }

    def render_full_hud():
        draw_info_panel(
            screen=screen,
            game=game,
            ai=ai,
            turn=turn,
            game_over=game_over,
            winner=winner,
            buttons=buttons,
            current_depth=current_depth,
            ai_status_text=ai_status_text
        )

    running = True

    while running:
        mouse_pos = pygame.mouse.get_pos()

        # Update button hover states
        for btn in buttons.values():
            btn.check_hover(mouse_pos)

        # Update hover column for disc drop
        if mouse_pos[0] < BOARD_WIDTH:
            hover_col = int(mouse_pos[0] // SQUARESIZE)
        else:
            hover_col = None

        # Process Pygame Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # 1. Handle UI Button Clicks
                if buttons["restart"].is_clicked(mouse_pos):
                    game.reset()
                    ai.reset_stats()
                    turn = PLAYER_PIECE
                    game_over = False
                    winner = None
                    winning_coords = []
                    ai_status_text = ""
                    continue

                if game_over and buttons["play_again"].is_clicked(mouse_pos):
                    game.reset()
                    ai.reset_stats()
                    turn = PLAYER_PIECE
                    game_over = False
                    winner = None
                    winning_coords = []
                    ai_status_text = ""
                    continue

                if not game_over and buttons["ai_first"].is_clicked(mouse_pos):
                    turn = AI_PIECE
                    continue

                # Depth selectors
                if buttons["depth_2"].is_clicked(mouse_pos):
                    current_depth = 2
                    ai.depth = 2
                    continue
                if buttons["depth_4"].is_clicked(mouse_pos):
                    current_depth = 4
                    ai.depth = 4
                    continue
                if buttons["depth_5"].is_clicked(mouse_pos):
                    current_depth = 5
                    ai.depth = 5
                    continue
                if buttons["depth_6"].is_clicked(mouse_pos):
                    current_depth = 6
                    ai.depth = 6
                    continue

                # 2. Handle Human Column Drop
                if not game_over and turn == PLAYER_PIECE and hover_col is not None:
                    col = hover_col
                    if ConnectFour.is_valid_location(game.board, col):
                        row = ConnectFour.get_next_open_row(game.board, col)
                        if row is not None:
                            # Animate drop
                            animate_disc_drop(
                                screen=screen,
                                board=game.board,
                                col=col,
                                target_row=row,
                                piece=PLAYER_PIECE,
                                ai_info_callback=render_full_hud
                            )
                            ConnectFour.drop_piece(game.board, row, col, PLAYER_PIECE)

                            # Check Win or Draw
                            if ConnectFour.check_win(game.board, PLAYER_PIECE):
                                game_over = True
                                winner = PLAYER_PIECE
                                winning_coords = ConnectFour.get_winning_positions(game.board, PLAYER_PIECE)
                            elif ConnectFour.is_draw(game.board):
                                game_over = True
                                winner = 0  # Draw
                            else:
                                turn = AI_PIECE

        # ---------------------------------------------------------
        # AI TURN EXECUTION (AUTOMATIC)
        # ---------------------------------------------------------
        if not game_over and turn == AI_PIECE:
            # Display thinking status so UI updates immediately without freezing
            ai_status_text = "AI Computing Optimal Move..."
            screen.fill(COLOR_BG)
            draw_board(screen, game.board, winning_coords)
            draw_hover_disc(screen, hover_col, turn, game_over)
            render_full_hud()
            pygame.display.update()

            # Small human-like deliberation pause (150ms) for visual polish
            pygame.time.delay(150)

            # Execute Minimax with Alpha-Beta Pruning
            ai_col, _ = ai.get_best_move(game.board, depth=current_depth)
            ai_status_text = ""

            if ConnectFour.is_valid_location(game.board, ai_col):
                row = ConnectFour.get_next_open_row(game.board, ai_col)
                if row is not None:
                    # Animate AI drop
                    animate_disc_drop(
                        screen=screen,
                        board=game.board,
                        col=ai_col,
                        target_row=row,
                        piece=AI_PIECE,
                        ai_info_callback=render_full_hud
                    )
                    ConnectFour.drop_piece(game.board, row, ai_col, AI_PIECE)

                    # Check Win or Draw
                    if ConnectFour.check_win(game.board, AI_PIECE):
                        game_over = True
                        winner = AI_PIECE
                        winning_coords = ConnectFour.get_winning_positions(game.board, AI_PIECE)
                    elif ConnectFour.is_draw(game.board):
                        game_over = True
                        winner = 0  # Draw
                    else:
                        turn = PLAYER_PIECE

        # Standard Frame Render
        screen.fill(COLOR_BG)
        draw_board(screen, game.board, winning_coords)
        draw_hover_disc(screen, hover_col, turn, game_over)
        render_full_hud()

        pygame.display.update()
        clock.tick(60)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
